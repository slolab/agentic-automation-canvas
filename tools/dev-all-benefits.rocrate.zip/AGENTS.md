# Dev: All benefit types

Target version: 0.1.0. Implement to match this specification exactly.

Development aid RO-Crate with every benefit metric represented once and repeated across tasks to test display groups.

Objective: Exercise all benefit types and display groups in collapsed view and Dashboard.

## Requirements

### Time benefits (task 1)

Time benefits (task 1): processing time = duration before → after; cycle time

- Processing time: 20 → 5 minutes
- Cycle time: 7 → 2 hours

### Time benefits (task 2)

Time benefits again (task 2): processing time — tests aggregation

- Processing time: 15 → 3 minutes

### Quality benefits (task 1)

Quality benefits: errorRate, reworkRate, precision, recall, satisfaction, accuracy (task 1)

- Error Rate: 5 → 1 %
- Rework Rate: 8 → 2 %
- Precision: 85 → 95 %
- Recall: 80 → 92 %
- Satisfaction (1–5 scale): 3 → 4.5 out of 5
- Accuracy: 90 → 98 %

### Quality benefits (task 2)

Quality again (task 2): errorRate, reworkRate — tests aggregation across tasks

- Error Rate: 4 → 0.5 %
- Rework Rate: 6 → 1 %

### Risk benefits (task 1)

Risk benefits: complianceIncidents, dataExposureRisk, auditFindings, probabilityOfHarm, securityVulnerabilities (task 1)

- Compliance Incidents (reduced to): 3 → 0.5 incidents/month
- Data Exposure Risk: high → low risk level
- Audit Findings (reduced to): 10 → 2 findings/audit
- Probability of Harm: 15 → 2 %
- Security Vulnerabilities (reduced to): 5 → 0 vulnerabilities

### Risk benefits (task 2)

Risk again (task 2): complianceIncidents, probabilityOfHarm — tests aggregation across tasks

- Compliance Incidents (reduced to): 2 → 0.2 incidents/month
- Probability of Harm: 10 → 1 %

### Enablement benefits (task 1)

Enablement benefits: newCapability, coverage, latencyToAnswer, throughput, availability (task 1)

- New Capability: no → yes capability
- Coverage (%): 60 → 95 %
- Latency to Answer: 120 → 5 seconds
- Throughput (units/hour): 100 → 500 units/hour
- Availability (%): 99 → 99.9 %

### Enablement benefits (task 2)

Enablement again (task 2): newCapability, coverage — tests aggregation across tasks

- New Capability: no → yes capability
- Coverage (%): 70 → 90 %

# Referral triage support

Target version: 0.1.0. Implement to match this specification exactly.

Incoming clinical referrals are read in the order they arrive, so urgent cases are often noticed days after they land. Staff re-read the same letters repeatedly to decide what is urgent.

Objective: Urgent referrals are surfaced on the day they arrive, with the wording that makes them urgent visible to the person triaging.

## Requirements

### requirement-simplified-only

- Unclassified benefit: Less time spent re-reading the same letters
- Unclassified benefit: Fewer urgent referrals noticed late
- Unclassified benefit: Days between arrival and triage decision
- Unclassified benefit: Urgent cases the clinician agrees were flagged correctly

## Data
-  (contains personal data)
